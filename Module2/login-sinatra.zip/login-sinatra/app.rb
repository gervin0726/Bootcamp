require 'sinatra'
require 'sinatra/reloader' if development?
require 'pry'

enable(:sessions)

# extra: que user sea un modelo en lib folder
@@users = [{username: "wolas", password: "B5%khjsd"}]

get '/' do
  erb(:index)
end

post "/log_in" do
  # comprobar que username y password machean a un usuario
end


post '/register' do
  # añadir un usuario
  # extras: 
      # no permitir username o password en blanco
      # no permitir username que ya este registrados
  if estan_en_blanco
    error 
    redirect
  else
    user = {username: params[:username], password: params[:password]}
    @@users << user
  end
  
  @message = "Registro completado. ahora mete tus datos, venga. "
  erb(:index)
end

get '/profile' do
  # solo puedes llegar si estas registrado
  if session[:logged_in]
    erb(:profile)
  else
    @message = "Eres un trampas"
    redirect('/')
  end
end